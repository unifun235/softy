re2c: error: YYFILL check is necessary if EOF rule is used
