american_fuzzy_lop/002.re:2:8: error: unexpected end of input
