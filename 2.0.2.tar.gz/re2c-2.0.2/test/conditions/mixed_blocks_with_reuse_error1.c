conditions/mixed_blocks_with_reuse_error1.re:3:8: error: cannot mix conditions with normal rules
