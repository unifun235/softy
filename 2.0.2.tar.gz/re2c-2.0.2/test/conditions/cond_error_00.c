conditions/cond_error_00.re:4:9: error: conditions are only allowed with '-c', '--conditions' option
