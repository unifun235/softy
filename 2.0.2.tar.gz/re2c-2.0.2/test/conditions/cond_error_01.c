conditions/cond_error_01.re:4:3: error: syntax error
