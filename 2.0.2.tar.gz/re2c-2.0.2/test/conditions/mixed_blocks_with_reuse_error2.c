conditions/mixed_blocks_with_reuse_error2.re:7:8: error: cannot mix conditions with normal rules
