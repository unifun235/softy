#!/bin/sh -e

pdflatex -shell-escape 2017_trofimovich_tagged_deterministic_finite_automata_with_lookahead.tex </dev/null > tdfa.build_log
