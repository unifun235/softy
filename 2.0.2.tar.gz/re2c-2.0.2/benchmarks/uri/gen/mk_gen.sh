ghc -O2 -Wall gen_uri.hs
