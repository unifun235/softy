
. ../../__bench_utils.sh

verify uri rfc3986
