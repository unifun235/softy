ghc -O2 -Wall gen_http.hs
