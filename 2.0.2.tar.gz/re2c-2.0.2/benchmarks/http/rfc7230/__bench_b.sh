
. ../../__bench_utils.sh

compile http rfc7230 "-b"
run_all http rfc7230

