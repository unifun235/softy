#ifndef _RE2C_BENCHMRKS_COMMON_STRINGS_DATE_
#define _RE2C_BENCHMRKS_COMMON_STRINGS_DATE_

static const char *date_strings[] = {
    "Mon Jan 01 2019 00:24:00 GMT",
    "Tue Feb 02 2018 01:24:00 GMT",
    "Wed Mar 03 2017 02:24:00 GMT",
    "Thu Apr 04 2016 03:24:00 GMT",
    "Fri May 05 2015 04:24:00 GMT",
    "Sat Jun 06 2014 05:24:00 GMT",
    "Sun Jul 07 2013 06:24:00 GMT",
    NULL
};

#endif // _RE2C_BENCHMRKS_COMMON_STRINGS_DATE_
